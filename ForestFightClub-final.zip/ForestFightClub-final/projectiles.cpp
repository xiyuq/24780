#include <stdio.h>
#include <stdlib.h>
#include "fssimplewindow.h"
#include "projectiles.h"
#include "fighters.h"

void Fireballs::fire(Fighters fox)
{
	y = fox.y + fox.h /4;
	if (fox.prevVx > 0 || fox.x == 0)
	{
		x = fox.x + fox.w;
		vx = 7;
	}
	else if (fox.prevVx < 0 || fox.x == 800 - fox.w)
	{
		x = fox.x;
		vx = -7;
	}
	else {
		x = fox.x;
		vx = -7;
	}
	hit = 0;
	state_fire = 1;
}

void Fireballs::initialize()
{
	x = 0;
	y = 0;
	vx = 0;
	hit = 0;
	state_fire = 0;
}

void Fireballs::draw()
{
	if (state_fire == 1)
	{
		glColor3ub(125, 0, 0);
		glBegin(GL_QUADS);
		glVertex2i(x - 10, y - 10);
		glVertex2i(x - 10, y + 10);
		glVertex2i(x + 10, y + 10);
		glVertex2i(x + 10, y - 10);
		glEnd();
	}
}

void Fireballs::move()
{
	x += vx;
}

int Fireballs::checkhit(Fighters frog)
{
	if (x < frog.x + frog.w && x > frog.x &&
        y < frog.y + frog.h && y > frog.y)
	{
		hit = 1;
		state_fire = 0;
	}
	else
	{
		hit = 0;
	}
	//printf("%d", hit);
	return hit;
}

void Fireballs::Explosion::initialize()
{
	counter = 0;
	state_exp = 0;
}

bool Fireballs::Explosion::Explode(int x, int y)
{
	if (0 == state_exp)
	{
		state_exp = 1;
		counter = 0;
		for (auto& par : particle)
		{
			par.p.x = (double)x;
			par.p.y = (double)y;
			par.v.x = (double)(rand() % 1001 - 500) / 50.0;
			par.v.y = (double)(rand() % 1001 - 500) / 50.0;
		}
		return true;
	}
	return false;
}

void Fireballs::Explosion::Draw(void)
{
	if (0 != state_exp)
	{
		glPointSize(2);
		glColor3ub(255, 0, 0);
		glBegin(GL_POINTS);
		for (auto par : particle)
		{
			glVertex2d(par.p.x, par.p.y);
		}
		glEnd();
	}
}

void Fireballs::Explosion::Move(void)
{
	if (0 != state_exp)
	{
		++counter;
		if (50 <= counter)
		{
			state_exp = 0;
		}

		for (auto& par : particle)
		{
			par.p.x += par.v.x;
			par.p.y += par.v.y;
		}
	}
}

void Bubbles::fire(Fighters frog)
{
	y = frog.y + frog.h / 4;
	if (frog.vx > 0 || frog.x == 0)
	{
		x = frog.x + frog.w;
		vx = 5;
	}
	//else if (frog.vx < 0 || frog.x == 800 - frog.w)
	else
	{
		x = frog.x;
		vx = -5;
	}
	hit = 0;
	state_fire = 1;
}

void Bubbles::initialize()
{
	x = 0;
	y = 0;
	vx = 0;
	hit = 0;
	state_fire = 0;
}

void Bubbles::draw()
{
	if (state_fire == 1)
	{
		glColor3ub(0, 125, 75);
		glBegin(GL_QUADS);
		glVertex2i(x - 10, y - 10);
		glVertex2i(x - 10, y + 10);
		glVertex2i(x + 10, y + 10);
		glVertex2i(x + 10, y - 10);
		glEnd();
	}
}

void Bubbles::move(int diff)
{
	x += (vx*diff);
}

int Bubbles::checkhit(Fighters fox)
{
	if (x < fox.x + fox.w && x > fox.x &&
        y < fox.y + fox.h && y > fox.y)
	{
		hit = 1;
		state_fire = 0;
	}
	else
	{
		hit = 0;
	}
	//printf("%d", hit);
	return hit;
}

int Bubbles::checkfb(Fireballs fb)
{
	if (x < fb.x + 10 && x > fb.x - 10 &&
		y<fb.y + 10 && y>fb.y - 10)
	{
		hit = 1;
		state_fire = 0;
	}
	else
	{
		hit = 0;
	}
	//printf("%d", hit);
	return hit;
}

void Bubbles::Explosion::initialize()
{
	counter = 0;
	state_exp = 0;
}

bool Bubbles::Explosion::Explode(int x, int y)
{
	if (0 == state_exp)
	{
		state_exp = 1;
		counter = 0;
		for (auto& par : particle)
		{
			par.p.x = (double)x;
			par.p.y = (double)y;
			par.v.x = (double)(rand() % 1001 - 500) / 50.0;
			par.v.y = (double)(rand() % 1001 - 500) / 50.0;
		}
		return true;
	}
	return false;
}

void Bubbles::Explosion::Draw(void)
{
	if (0 != state_exp)
	{
		glPointSize(2);
		glColor3ub(0, 255, 0);
		glBegin(GL_POINTS);
		for (auto par : particle)
		{
			glVertex2d(par.p.x, par.p.y);
		}
		glEnd();
	}
}

void Bubbles::Explosion::Move(void)
{
	if (0 != state_exp)
	{
		++counter;
		if (50 <= counter)
		{
			state_exp = 0;
		}

		for (auto& par : particle)
		{
			par.p.x += par.v.x;
			par.p.y += par.v.y;
		}
	}
}
