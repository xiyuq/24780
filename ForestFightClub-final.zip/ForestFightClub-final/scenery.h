#ifndef SCENERY_IS_INCLUDED
#define SCENERY_IS_INCLUDED

const double YsPi = 3.14159265;
const double g = -98;
const double dt = 0.002;

const int nblock = 40;
const int hitted = 8;

class Flower
{
public:
	double x, y, vx, vy, theta, state;

	void Initialize(void);
	void Draw(double cr, int bg);
	void Move(int bg);
};

class Block
{
public:
	int
		state, x, y, w, h;

	void Draw(int xi);
	void Initialize(void);
	void Disappear(void);
	void Notmovebar(int xi);

};

#endif