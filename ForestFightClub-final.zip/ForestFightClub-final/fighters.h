#ifndef fighters_h
#define fighters_h

class Fighters
{
public:
    int x, prevx, y, state, charType, w, h, jumpState;
    double vx, prevVx, vy;
    
    void Initialize (int type);
    void Move(int charType);
};

#endif
