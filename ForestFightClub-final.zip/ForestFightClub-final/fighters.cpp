#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "fssimplewindow.h"
#include "fighters.h"

const int dt = 10;

void Fighters::Initialize(int type)
{
    charType=type;
    if (charType==0) //fox
    {
        x = 400;
        y = 500;
    }
    else if (charType==1)//frog
    {
        x = 0;
        y = 500;
    }
    prevx = x;
    w = 50;
    h = 50;
    state = 1;
    vx = 0;
    prevVx = 0;
    vy = 0;
    jumpState = 0;
}

void Fighters::Move(int charType)
{
    x = x + vx*dt;
    if (x>800-w)
        x = 800-w;
    else if (x<0)
        x = 0;
    
    y = y + vy*dt;
    if (y>500)
    {
        y=500;
        jumpState=0;
    }
    
    if (charType==0 && jumpState==1)
    {
        vy+= 0.1;
    }
	else if (charType == 1 && jumpState == 1)
	{
		vy += 0.018 ;
	}
}
