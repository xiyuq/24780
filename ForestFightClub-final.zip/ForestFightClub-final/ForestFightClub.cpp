#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#include "fssimplewindow.h"
#include "ysglfontdata.h"
#include "yspng.h"
#include "scenery.h"
#include "fighters.h"
#include "projectiles.h"

class GameMenu
{
public:
	int key;
	int chooseDifficulty = 0; // Whether difficulty has been chosen or not
	int difficulty; // Difficulty level
	void Run(void);
    void Instructions(void);
};

void GameMenu::Run(void)
{
	for (;;)
	{
		FsPollDevice();
		key = FsInkey();
		if (FSKEY_S == key)
		{
			chooseDifficulty = 1;
		}
        else if (FSKEY_E == key)
        {
            break;
        }
        else if (FSKEY_I == key)
        {
            Instructions();
        }

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        if (chooseDifficulty == 1)
        {
            
            glColor3ub(0, 0, 0);
            glRasterPos2i(40, 150);
            YsGlDrawFontBitmap32x48("Choose Difficulty Level");
            glRasterPos2i(130, 200);
            YsGlDrawFontBitmap16x20("1...Easy   2...Medium   3...Hard");
            if (FSKEY_1 == key)
            {
                difficulty = 1;
                break;
            }
            else if (FSKEY_2 == key)
            {
                difficulty = 2;
                break;
            }
            else if (FSKEY_3 == key)
            {
                difficulty = 3;
                break;
            }
        }
		
        else
        {
            glColor3ub(0, 0, 0);
            glRasterPos2i(125, 150);
            YsGlDrawFontBitmap32x48("FOREST FIGHT CLUB");
            glRasterPos2i(300, 200);
            YsGlDrawFontBitmap16x20("S...Start");
            glRasterPos2i(300, 220);
            YsGlDrawFontBitmap16x20("E...End");
            glRasterPos2i(300, 260);
            YsGlDrawFontBitmap16x20("I...Instructions");
        }

		FsSwapBuffers();
		FsSleep(10);
	}
}

void GameMenu::Instructions(void)
{
    for (;;)
    {
        FsPollDevice();
        key = FsInkey();
        if (FSKEY_S == key)
        {
            chooseDifficulty = 1;
            break;
        }
        if (FSKEY_E == key)
        {
            chooseDifficulty = 0;
            break;
        }
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        glColor3ub(0, 0, 0);
        glRasterPos2i(125, 100);
        YsGlDrawFontBitmap32x48("FOREST FIGHT CLUB");
        glRasterPos2i(50, 150);
        YsGlDrawFontBitmap16x20("Game Instructions:");
        glRasterPos2i(50, 200);
        YsGlDrawFontBitmap12x16("In this game you are the fox fighting against the evil frog!");
        glRasterPos2i(50, 225);
        YsGlDrawFontBitmap12x16("You must kill the frog before you are killed. Avoid touching");
        glRasterPos2i(50, 250);
        YsGlDrawFontBitmap12x16("the bubbles the frog shoots at you. Otherwise your health ");
        glRasterPos2i(50, 275);
        YsGlDrawFontBitmap12x16("will go down!");
        glRasterPos2i(50, 310);
        YsGlDrawFontBitmap12x16("You can control the fox using the following keys:");
        glRasterPos2i(100, 345);
        YsGlDrawFontBitmap16x20("Left Arrow....Move Left");
        glRasterPos2i(100, 375);
        YsGlDrawFontBitmap16x20("Right Arrow...Move Right");
        glRasterPos2i(100, 405);
        YsGlDrawFontBitmap16x20("Up Arrow......Jump");
        glRasterPos2i(100, 435);
        YsGlDrawFontBitmap16x20("A Key.........Shoot");
        glRasterPos2i(180, 550);
        YsGlDrawFontBitmap16x20("S...Start");
        glRasterPos2i(400, 550);
        YsGlDrawFontBitmap16x20("E...Back to Menu");
        FsSwapBuffers();
        
        FsSleep(10);
    }
}

class Game
{
public:
	void Run(int diff); // Take difficulty level as input to set up game difficulty
};

void Game::Run(int diff)
{
	int bg = rand() % 3;
    int nFireballs;
    int nBubbles;
    if (diff == 1)
    {
        nFireballs = 5;
        nBubbles = 5;
    }
    else if (diff == 2)
    {
        nFireballs = 4;
        nBubbles = 6;
    }
    else if (diff == 3)
    {
        nFireballs = 3;
        nBubbles = 7;
    }
	const int nExplosionsF = nFireballs;
    const int nExplosionsB = nBubbles;
	int itcount = 0;
	int foxhealth = nblock;
	int froghealth = nblock;
	int frogmove = 0;
	int frogshoot = 0;
	int win = 0;
	int foxhit = 0;
	int froghit = 0;
	int foxcount = 0;
	int frogcount = 0;
	int exppng = 0;
	int expcount = 0;
	int expx = 0;
	int expy = 0;
	int nBall;

	if (bg == 0) // Ice
	{
		nBall = 100;
	}
	else if (bg == 1) // Grass
	{
		nBall = 3;
	}
	else // Fire
	{
		nBall = 25;
	}

	std::vector<Flower> flower(nBall);
	Block block[nblock];
	Block fblock[nblock];
	Fireballs fballs[nFireballs];
	Fireballs::Explosion exp[nExplosionsF];
	Bubbles bubble[nBubbles];
	Bubbles::Explosion expb[nExplosionsB];
	Fighters fox;
	Fighters frog;

	fox.Initialize(0);
	frog.Initialize(1);
	for (auto& f : flower)
	{
		f.Initialize();
	}
	int j = 0;
	for (auto& bl : block)
	{
		bl.Initialize();
		bl.x = 280.0 - hitted * j;
		j++;
	}
	j = 0;
	for (auto& fbl : fblock)
	{
		fbl.Initialize();
		fbl.x = 480.0 + hitted * j;
		j++;
	}
	for (auto& fb : fballs)
	{
		fb.initialize();
	}
	for (auto& e : exp)
	{
		e.initialize();
	}
	for (auto& bu : bubble)
	{
		bu.initialize();
	}
	for (auto& eb : expb)
	{
		eb.initialize();
	}

	//FsChangeToProgramDir();
	// Image loading

	YsRawPngDecoder png;
	YsRawPngDecoder FoxHitR;
	YsRawPngDecoder FoxHitL;
	YsRawPngDecoder FoxAttackR;
	YsRawPngDecoder FoxAttackL;
	YsRawPngDecoder FrogHitR;
	YsRawPngDecoder FrogHitL;
	YsRawPngDecoder FoxMove1R;
	YsRawPngDecoder FoxMove1L;
	YsRawPngDecoder FoxMove2R;
	YsRawPngDecoder FoxMove2L;
	YsRawPngDecoder FoxMove3R;
	YsRawPngDecoder FoxMove3L;
	YsRawPngDecoder FrogMove1R;
	YsRawPngDecoder FrogMove1L;
	YsRawPngDecoder FrogMove2R;
	YsRawPngDecoder FrogMove2L;
	YsRawPngDecoder FrogMove3R;
	YsRawPngDecoder FrogMove3L;
	YsRawPngDecoder FrogStaticR;
	YsRawPngDecoder FrogStaticL;
	YsRawPngDecoder FrogDieR;
	YsRawPngDecoder FrogDieL;
	YsRawPngDecoder FoxDieR;
	YsRawPngDecoder FoxDieL;
	YsRawPngDecoder BubProj;
	YsRawPngDecoder IceProjL;
	YsRawPngDecoder IceProjR;
	YsRawPngDecoder FireProjL;
	YsRawPngDecoder FireProjR;
	YsRawPngDecoder ExplProj;

	if (bg == 0)
	{
		char fName[25] = "ice.png";
		if (YSOK == png.Decode(fName))
		{
			png.Flip();
		}
		else
		{
			printf("error\n");
			return;
		}
	}
	else if (bg == 1)
	{
		char fName[25] = "grass.png";
		if (YSOK == png.Decode(fName))
		{
			png.Flip();
		}
		else
		{
			printf("error\n");
			return;
		}
	}
	else {
		char fName[25] = "fire.png";
		if (YSOK == png.Decode(fName))
		{
			png.Flip();
		}
		else
		{
			printf("error\n");
			return;
		}
	}

	char FoHR[25] = "fox_behitted.png";
	char FoHL[25] = "fox_behitted_left.png";
	char FoAR[25] = "fox_hit.png";
	char FoAL[25] = "fox_hit_left.png";
	char FrHR[25] = "frog_hitted.png";
	char FrHL[25] = "frog_hitted_left.png";
	char FoM1R[25] = "fox_move1.png";
	char FoM1L[25] = "fox_move1_left.png";
	char FoM2R[25] = "fox_move2.png";
	char FoM2L[25] = "fox_move2_left.png";
	char FoM3R[25] = "fox_move3.png";
	char FoM3L[25] = "fox_move3_left.png";
	char FrM1R[25] = "frog_move1.png";
	char FrM1L[25] = "frog_move1_left.png";
	char FrM2R[25] = "frog_move2.png";
	char FrM2L[25] = "frog_move2_left.png";
	char FrM3R[25] = "frog_move3.png";
	char FrM3L[25] = "frog_move3_left.png";
	char FrSR[25] = "frog_static.png";
	char FrSL[25] = "frog_static_left.png";
	char FrDR[25] = "frog_die.png";
	char FrDL[25] = "frog_die_left.png";
	char FoDR[25] = "fox_die.png";
	char FoDL[25] = "fox_die_left.png";
	char bub[25] = "bubble.png";
	char icel[25] = "iceproj_left.png";
	char icer[25] = "iceproj.png";
	char firer[25] = "fireball.png";
	char firel[25] = "fireball_left.png";
	char expl[25] = "explosion.png";

	if (YSOK == FoxHitR.Decode(FoHR))
	{
		FoxHitR.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxHitL.Decode(FoHL))
	{
		FoxHitL.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxAttackR.Decode(FoAR))
	{
		FoxAttackR.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxAttackL.Decode(FoAL))
	{
		FoxAttackL.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogHitR.Decode(FrHR))
	{
		FrogHitR.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogHitL.Decode(FrHL))
	{
		FrogHitL.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxMove1R.Decode(FoM1R))
	{
		FoxMove1R.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxMove1L.Decode(FoM1L))
	{
		FoxMove1L.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxMove2R.Decode(FoM2R))
	{
		FoxMove2R.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxMove2L.Decode(FoM2L))
	{
		FoxMove2L.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxMove3R.Decode(FoM3R))
	{
		FoxMove3R.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxMove3L.Decode(FoM3L))
	{
		FoxMove3L.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogMove1R.Decode(FrM1R))
	{
		FrogMove1R.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogMove1L.Decode(FrM1L))
	{
		FrogMove1L.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogMove2R.Decode(FrM2R))
	{
		FrogMove2R.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogMove2L.Decode(FrM2L))
	{
		FrogMove2L.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogMove3R.Decode(FrM3R))
	{
		FrogMove3R.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogMove3L.Decode(FrM3L))
	{
		FrogMove3L.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogStaticR.Decode(FrSR))
	{
		FrogStaticR.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogStaticL.Decode(FrSL))
	{
		FrogStaticL.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogDieR.Decode(FrDR))
	{
		FrogDieR.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FrogDieL.Decode(FrDL))
	{
		FrogDieL.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxDieR.Decode(FoDR))
	{
		FoxDieR.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FoxDieL.Decode(FoDL))
	{
		FoxDieL.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == ExplProj.Decode(expl))
	{
		ExplProj.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == BubProj.Decode(bub))
	{
		BubProj.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == IceProjL.Decode(icel))
	{
		IceProjL.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == IceProjR.Decode(icer))
	{
		IceProjR.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FireProjL.Decode(firel))
	{
		FireProjL.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}
	if (YSOK == FireProjR.Decode(firer))
	{
		FireProjR.Flip();
	}
	else
	{
		printf("error\n");
		return;
	}


	for (;;)
	{
		FsPollDevice();

		auto key = FsInkey();
		if (FSKEY_E == key)
		{
			break;
		}
		for (auto& f : flower)
		{
			f.theta += 10;
		}

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Draw commands go here

		int window_wid, window_hei;
		FsGetWindowSize(window_wid, window_hei);
		glRasterPos2i(0, png.hei - 1);
		glDrawPixels(png.wid, png.hei, GL_RGBA, GL_UNSIGNED_BYTE, png.rgba);

		for (auto& f : flower)
		{
			f.Draw(9,bg);
		}
		for (int i = 0; i < nblock; ++i)
		{
			block[i].Notmovebar(block[i].x);
			fblock[i].Notmovebar(fblock[i].x);
		}

		for (int i = 0; i < nblock; ++i)
		{
			if (block[i].state != 0)
			{
				block[i].Draw(block[i].x);
			}
			if (fblock[i].state != 0)
			{
				fblock[i].Draw(fblock[i].x);
			}
		}

		glColor3ub(0, 0, 0);
		glRasterPos2i(5, 25);
		YsGlDrawFontBitmap16x20("Fox");
		glRasterPos2i(725, 25);
		YsGlDrawFontBitmap16x20("Frog");
		
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		if (FsGetKeyState(FSKEY_A))
		{
			if (fox.prevVx <= 0)
			{
				fox.w = FoxAttackL.wid;
				fox.h = FoxAttackL.hei;
				glRasterPos2i(fox.x, fox.y + FoxAttackL.hei * 3 / 4);
				glDrawPixels(FoxAttackL.wid, FoxAttackL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxAttackL.rgba);
			}
			else
			{
				fox.w = FoxAttackR.wid;
				fox.h = FoxAttackR.hei;
				glRasterPos2i(fox.x, fox.y + FoxAttackR.hei * 3 / 4);
				glDrawPixels(FoxAttackR.wid, FoxAttackR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxAttackR.rgba);
			}
		}
		else if (foxhit == 1 && fox.prevVx>0)
		{
			fox.w = FoxHitR.wid;
			fox.h = FoxHitR.hei;
			glRasterPos2i(fox.x, fox.y + FoxHitR.hei * 3 / 4);
			glDrawPixels(FoxHitR.wid, FoxHitR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxHitR.rgba);
		}
		else if (foxhit == 1)
		{
			fox.w = FoxHitL.wid;
			fox.h = FoxHitL.hei;
			glRasterPos2i(fox.x, fox.y + FoxHitL.hei * 3 / 4);
			glDrawPixels(FoxHitL.wid, FoxHitL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxHitL.rgba);
		}
		else {
			if (fox.x < 266 && fox.prevVx <= 0)
			{
				fox.w = FoxMove1L.wid;
				fox.h = FoxMove1L.hei;
				glRasterPos2i(fox.x, fox.y + FoxMove1L.hei * 3 / 4);
				glDrawPixels(FoxMove1L.wid, FoxMove1L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxMove1L.rgba);
			}
			else if (fox.x >= 266 && fox.x < 533 && fox.prevVx <= 0)
			{
				fox.w = FoxMove2L.wid;
				fox.h = FoxMove2L.hei;
				glRasterPos2i(fox.x, fox.y + FoxMove2L.hei * 3 / 4);
				glDrawPixels(FoxMove2L.wid, FoxMove2L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxMove2L.rgba);
			}
			else if (fox.prevVx <= 0)
			{
				fox.w = FoxMove3L.wid;
				fox.h = FoxMove3L.hei;
				glRasterPos2i(fox.x, fox.y + FoxMove3L.hei * 3 / 4);
				glDrawPixels(FoxMove3L.wid, FoxMove3L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxMove3L.rgba);
			}
			else if (fox.x < 266)
			{
				fox.w = FoxMove1R.wid;
				fox.h = FoxMove1R.hei;
				glRasterPos2i(fox.x, fox.y + FoxMove1R.hei * 3 / 4);
				glDrawPixels(FoxMove1R.wid, FoxMove1R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxMove1R.rgba);
			}
			else if (fox.x >= 266 && fox.x < 533)
			{
				fox.w = FoxMove2R.wid;
				fox.h = FoxMove2R.hei;
				glRasterPos2i(fox.x, fox.y + FoxMove2R.hei * 3 / 4);
				glDrawPixels(FoxMove2R.wid, FoxMove2R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxMove2R.rgba);
			}
			else
			{
				fox.w = FoxMove3R.wid;
				fox.h = FoxMove3R.hei;
				glRasterPos2i(fox.x, fox.y + FoxMove3R.hei * 3 / 4);
				glDrawPixels(FoxMove3R.wid, FoxMove3R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxMove3R.rgba);
			}
		}

		if (froghit == 1 && (frog.x == 0 || frog.vx > 0))
		{
			frog.w = FrogHitR.wid;
			frog.h = FrogHitR.hei;
			glRasterPos2i(frog.x, frog.y + FrogHitR.hei * 3 / 4);
			glDrawPixels(FrogHitR.wid, FrogHitR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogHitR.rgba);
		}
		else if (froghit == 1)
		{
			frog.w = FrogHitL.wid;
			frog.h = FrogHitL.hei;
			glRasterPos2i(frog.x, frog.y + FrogHitL.hei * 3 / 4);
			glDrawPixels(FrogHitL.wid, FrogHitL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogHitL.rgba);
		}
		else {
			if (frog.vx == 0 && frog.x == 0)
			{
				frog.w = FrogStaticR.wid;
				frog.h = FrogStaticR.hei;
				glRasterPos2i(frog.x, frog.y + FrogStaticR.hei * 3 / 4);
				glDrawPixels(FrogStaticR.wid, FrogStaticR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogStaticR.rgba);
			}
			else if (frog.vx == 0)
			{
				frog.w = FrogStaticL.wid;
				frog.h = FrogStaticL.hei;
				glRasterPos2i(frog.x, frog.y + FrogStaticL.hei * 3 / 4);
				glDrawPixels(FrogStaticL.wid, FrogStaticL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogStaticL.rgba);
			}
			else if (frog.x < 266 && frog.vx <= 0)
			{
				frog.w = FrogMove3L.wid;
				frog.h = FrogMove3L.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove3L.hei * 3 / 4);
				glDrawPixels(FrogMove3L.wid, FrogMove3L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove3L.rgba);
			}
			else if (frog.x >= 266 && frog.x < 533 && frog.vx <= 0)
			{
				frog.w = FrogMove2L.wid;
				frog.h = FrogMove2L.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove2L.hei * 3 / 4);
				glDrawPixels(FrogMove2L.wid, FrogMove2L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove2L.rgba);
			}
			else if (frog.vx <= 0)
			{
				frog.w = FrogMove1L.wid;
				frog.h = FrogMove1L.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove1L.hei * 3 / 4);
				glDrawPixels(FrogMove1L.wid, FrogMove1L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove1L.rgba);
			}
			else if (frog.x < 266)
			{
				frog.w = FrogMove1R.wid;
				frog.h = FrogMove1R.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove1R.hei * 3 / 4);
				glDrawPixels(FrogMove1R.wid, FrogMove1R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove1R.rgba);
			}
			else if (frog.x >= 266 && frog.x < 533)
			{
				frog.w = FrogMove2R.wid;
				frog.h = FrogMove2R.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove2R.hei * 3 / 4);
				glDrawPixels(FrogMove2R.wid, FrogMove2R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove2R.rgba);
			}
			else
			{
				frog.w = FrogStaticL.wid;
				frog.h = FrogMove3R.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove3R.hei * 3 / 4);
				glDrawPixels(FrogMove3R.wid, FrogMove3R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove3R.rgba);
			}
		}
		if (exppng == 1)
		{
			glRasterPos2i(expx, expy + ExplProj.hei * 3 / 4);
			glDrawPixels(ExplProj.wid, ExplProj.hei, GL_RGBA, GL_UNSIGNED_BYTE, ExplProj.rgba);
		}

		for (auto& fb : fballs)
		{
			if (fb.state_fire == 1)
			{
				if (bg != 0)
				{
					if (fb.vx < 0)
					{
						glRasterPos2i(fb.x, fb.y + FireProjL.hei * 3 / 4);
						glDrawPixels(FireProjL.wid, FireProjL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FireProjL.rgba);
					}
					else
					{
						glRasterPos2i(fb.x, fb.y + FireProjR.hei * 3 / 4);
						glDrawPixels(FireProjR.wid, FireProjR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FireProjR.rgba);
					}
				}
				else
				{
					if (fb.vx < 0)
					{
						glRasterPos2i(fb.x, fb.y + IceProjL.hei * 3 / 4);
						glDrawPixels(IceProjL.wid, IceProjL.hei, GL_RGBA, GL_UNSIGNED_BYTE, IceProjL.rgba);
					}
					else
					{
						glRasterPos2i(fb.x, fb.y + IceProjR.hei * 3 / 4);
						glDrawPixels(IceProjR.wid, IceProjR.hei, GL_RGBA, GL_UNSIGNED_BYTE, IceProjR.rgba);
					}
				}
			}
		}
		for (auto& e : exp)
		{
			e.Draw();
		}
		for (auto& bu : bubble)
		{
			if (bu.state_fire == 1)
			{
				glRasterPos2i(bu.x, bu.y + BubProj.hei * 3 / 4);
				glDrawPixels(BubProj.wid, BubProj.hei, GL_RGBA, GL_UNSIGNED_BYTE, BubProj.rgba);
			}
		}
		for (auto& eb : expb)
		{
			eb.Draw();
		}

		FsSwapBuffers();

		// Movement commands go here

		for (int i = 0; i < nBall; i++)
		{
			if (0 != flower[i].state)
			{
				flower[i].Move(bg);
			}
		}

		if (FsGetKeyState(FSKEY_LEFT) && fox.x!=0)
		{
			fox.prevVx = fox.vx;
			fox.vx = -0.5;
			fox.prevx = fox.x;
		}
		else if (FsGetKeyState(FSKEY_RIGHT) && fox.x != 800 - fox.w)
		{
			fox.prevVx = fox.vx;
			fox.vx = 0.5;
			fox.prevx = fox.x;
		}
		else //if (fox.x == 0 || fox.x == 800 - fox.w)
		{
			fox.vx = 0;
			fox.prevx = fox.x;
		}
        if (FSKEY_UP == key)
        {
            if (fox.jumpState==0)
            {
                fox.jumpState=1;
                fox.vy=-2;
            }
        }

		if (itcount % 107 == 0) // Every 107 iterations, give the frog a chance to move.
		{
			frogmove = rand() % 3;
		}
		if (frogmove == 1 && frog.x != 0)
		{
			frog.jumpState = 1;
			frog.vy = -0.8;
			frog.vx = -0.8;
			frog.prevx = frog.x;
			frogmove = 0;
		}
		else if (frogmove == 2 && frog.x != 800 - frog.w)
		{
			frog.jumpState = 1;
			frog.vy = -0.8;
			frog.vx = 0.8;
			frog.prevx = frog.x;
			frogmove = 0;
		}
		else if (frog.x == 0 || frog.x == 800 - frog.w)
		{
			frog.prevVx = frog.vx;
			frog.vx = 0;
			frog.prevx = frog.x;
		}

		if ((frog.x < fox.x + fox.w) && (frog.x > fox.x) &&
			(frog.y < fox.y+fox.h) && (frog.y>fox.y))
		{
			for (auto& bl : block)
			{
				if (bl.state == 1)
				{
					foxhealth--;
					bl.state = 0;
					break;
				}
			}
		}
		else if (fox.x == 0 || fox.x == 800 - fox.w)
		{
			for (auto& bl : block)
			{
				if (bl.state == 1 && itcount % 10 == 0)
				{
					foxhealth--;
					bl.state = 0;
					break;
				}
			}
		}

		fox.Move(0);
		frog.Move(1);

		// Projectile handling commands go here

		if (FSKEY_A == key)
		{
			for (auto& fb : fballs)
			{
				if (fb.state_fire == 0)
				{
					fb.fire(fox);
					break;
				}
			}
		}

		if (itcount % (37/diff) == 0) // Every 37/difficulty iterations, give the frog a chance to shoot.
		{
			frogshoot=rand()%2;
			if (frogshoot == 1)
			{
				for (auto& bu : bubble)
				{
					if (bu.state_fire == 0)
					{
						bu.fire(frog);
						break;
					}
				}
			}
		}

		for (auto& fb : fballs)
		{
			if (fb.state_fire == 1)
			{
				fb.move();
			}
			if (fb.x > 800 || fb.x < -10)
			{
				fb.state_fire = 0;
			}
		}

		for (auto& e : exp)
		{
			if (e.state_exp == 1)
			{
				e.Move();
			}
		}

		for (auto& bu : bubble)
		{
			if (bu.state_fire == 1)
			{
				bu.move(diff);
			}
			if (bu.x > 800 || bu.x < -10)
			{
				bu.state_fire = 0;
			}
		}

		for (auto& eb : expb)
		{
			if (eb.state_exp == 1)
			{
				eb.Move();
			}
		}

		for (auto& fb : fballs)
		{
			if (1 == fb.state_fire)
			{
				if (1 == fb.checkhit(frog))
				{
					froghit = 1;
					frogcount = itcount;
					fb.state_fire = 0;
					for (auto& e : exp)
					{
						if (e.state_exp == 0)
						{
							e.Explode(fb.x, fb.y);
							break;
						}
					}
					for (auto& fbl : fblock)
					{
						if (fbl.state == 1)
						{
							froghealth--;
							fbl.state = 0;
							break;
						}
					}
				}
				for (auto& bu : bubble)
				{
					if (1 == bu.state_fire)
					{
						if (1 == bu.checkfb(fb))
						{
							exppng = 1;
							expcount = itcount;
							expx = bu.x;
							expy = bu.y;
							fb.state_fire = 0;
							bu.state_fire = 0;
							for (auto& e : exp)
							{
								if (e.state_exp == 0)
								{
									e.Explode(fb.x, fb.y);
									break;
								}
							}
							for (auto& eb : expb)
							{
								if (eb.state_exp == 0)
								{
									eb.Explode(bu.x, bu.y);
									break;
								}
							}
						}
					}
				}
			}
		}

		for (auto& bu : bubble)
		{
			if (1 == bu.state_fire)
			{
				if (1 == bu.checkhit(fox))
				{
					foxhit = 1;
					foxcount = itcount;
					bu.state_fire = 0;
					for (auto& eb : expb)
					{
						if (eb.state_exp == 0)
						{
							eb.Explode(bu.x, bu.y);
							break;
						}
					}
					for (auto& bl : block)
					{
						if (bl.state == 1)
						{
							foxhealth--;
							bl.state = 0;
							break;
						}
					}
				}
			}
		}

		if (foxhealth <= 0)
		{
			win = 0;
			break;
		}
		else if (froghealth <= 0)
		{
			win = 1;
			break;
		}

		if (itcount - foxcount > 10)
		{
			foxhit = 0;
		}
		if (itcount - frogcount > 10)
		{
			froghit = 0;
		}
		if (itcount - expcount > 10)
		{
			exppng = 0;
		}

		itcount++;

		FsSleep(10);
	}

	for (int i=0;i<500;i++)
	{
		FsPollDevice();

		auto key = FsInkey();
		if (FSKEY_E == key)
		{
			break;
		}
		for (auto& f : flower)
		{
			f.theta += 10;
		}

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Draw commands go here

		int window_wid, window_hei;
		FsGetWindowSize(window_wid, window_hei);
		glRasterPos2i(0, png.hei - 1);
		glDrawPixels(png.wid, png.hei, GL_RGBA, GL_UNSIGNED_BYTE, png.rgba);

		for (auto& f : flower)
		{
			f.Draw(9,bg);
		}
		for (int i = 0; i < nblock; ++i)
		{
			if (block[i].state != 0)
			{
				block[i].Draw(block[i].x);
			}
			if (fblock[i].state != 0)
			{
				fblock[i].Draw(fblock[i].x);
			}
		}
		for (int i = 0; i < nblock; ++i)
		{
			block[i].Notmovebar(block[i].x);
			fblock[i].Notmovebar(fblock[i].x);
		}

		glColor3ub(0, 0, 0);
		glRasterPos2i(5, 25);
		YsGlDrawFontBitmap16x20("Fox");
		glRasterPos2i(725, 25);
		YsGlDrawFontBitmap16x20("Frog");
		
		// Draw commands are called one last time to show victory or defeat

		if (win == 0)
		{
			if (fox.prevVx <= 0)
			{
				fox.w = FoxDieL.wid;
				fox.h = FoxDieL.hei;
				glRasterPos2i(fox.x, fox.y + FoxDieL.hei * 3 / 4);
				glDrawPixels(FoxDieL.wid, FoxDieL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxDieL.rgba);
			}
			else
			{
				fox.w = FoxDieR.wid;
				fox.h = FoxDieR.hei;
				glRasterPos2i(fox.x, fox.y + FoxDieR.hei * 3 / 4);
				glDrawPixels(FoxDieR.wid, FoxDieR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxDieR.rgba);
			}
			if (frog.vx == 0 && frog.x == 0)
			{
				frog.w = FrogStaticR.wid;
				frog.h = FrogStaticR.hei;
				glRasterPos2i(frog.x, frog.y + FrogStaticR.hei * 3 / 4);
				glDrawPixels(FrogStaticR.wid, FrogStaticR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogStaticR.rgba);
			}
			else if (frog.vx == 0)
			{
				frog.w = FrogStaticL.wid;
				frog.h = FrogStaticL.hei;
				glRasterPos2i(frog.x, frog.y + FrogStaticL.hei * 3 / 4);
				glDrawPixels(FrogStaticL.wid, FrogStaticL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogStaticL.rgba);
			}
			else if (frog.x < 266 && frog.vx <= 0)
			{
				frog.w = FrogMove3L.wid;
				frog.h = FrogMove3L.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove3L.hei * 3 / 4);
				glDrawPixels(FrogMove3L.wid, FrogMove3L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove3L.rgba);
			}
			else if (frog.x >= 266 && frog.x < 533 && frog.vx <= 0)
			{
				frog.w = FrogMove2L.wid;
				frog.h = FrogMove2L.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove2L.hei * 3 / 4);
				glDrawPixels(FrogMove2L.wid, FrogMove2L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove2L.rgba);
			}
			else if (frog.vx <= 0)
			{
				frog.w = FrogMove1L.wid;
				frog.h = FrogMove1L.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove1L.hei * 3 / 4);
				glDrawPixels(FrogMove1L.wid, FrogMove1L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove1L.rgba);
			}
			else if (frog.x < 266)
			{
				frog.w = FrogMove1R.wid;
				frog.h = FrogMove1R.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove1R.hei * 3 / 4);
				glDrawPixels(FrogMove1R.wid, FrogMove1R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove1R.rgba);
			}
			else if (frog.x >= 266 && frog.x < 533)
			{
				frog.w = FrogMove2R.wid;
				frog.h = FrogMove2R.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove2R.hei * 3 / 4);
				glDrawPixels(FrogMove2R.wid, FrogMove2R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove2R.rgba);
			}
			else
			{
				frog.w = FrogStaticL.wid;
				frog.h = FrogMove3R.hei;
				glRasterPos2i(frog.x, frog.y + FrogMove3R.hei * 3 / 4);
				glDrawPixels(FrogMove3R.wid, FrogMove3R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogMove3R.rgba);
			}
		}
		else
		{
			if (fox.prevVx <= 0)
			{
				fox.w = FoxMove1L.wid;
				fox.h = FoxMove1L.hei;
				glRasterPos2i(fox.x, fox.y + FoxMove1L.hei * 3 / 4);
				glDrawPixels(FoxMove1L.wid, FoxMove1L.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxMove1L.rgba);
			}
			else
			{
				fox.w = FoxMove1R.wid;
				fox.h = FoxMove1R.hei;
				glRasterPos2i(fox.x, fox.y + FoxMove1R.hei * 3 / 4);
				glDrawPixels(FoxMove1R.wid, FoxMove1R.hei, GL_RGBA, GL_UNSIGNED_BYTE, FoxMove1R.rgba);
			}
			if (frog.x <= 400)
			{
				frog.w = FrogDieL.wid;
				frog.h = FrogDieL.hei;
				glRasterPos2i(frog.x, frog.y + FrogDieL.hei * 3 / 4);
				glDrawPixels(FrogDieL.wid, FrogDieL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogDieL.rgba);
			}
			else
			{
				frog.w = FrogDieR.wid;
				frog.h = FrogDieR.hei;
				glRasterPos2i(frog.x, frog.y + FrogDieR.hei * 3 / 4);
				glDrawPixels(FrogDieR.wid, FrogDieR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FrogDieR.rgba);
			}
		}

		for (auto& fb : fballs)
		{
			if (fb.state_fire == 1)
			{
				if (bg != 0)
				{
					if (fb.vx < 0)
					{
						glRasterPos2i(fb.x, fb.y + FireProjL.hei * 3 / 4);
						glDrawPixels(FireProjL.wid, FireProjL.hei, GL_RGBA, GL_UNSIGNED_BYTE, FireProjL.rgba);
					}
					else
					{
						glRasterPos2i(fb.x, fb.y + FireProjR.hei * 3 / 4);
						glDrawPixels(FireProjR.wid, FireProjR.hei, GL_RGBA, GL_UNSIGNED_BYTE, FireProjR.rgba);
					}
				}
				else
				{
					if (fb.vx < 0)
					{
						glRasterPos2i(fb.x, fb.y + IceProjL.hei * 3 / 4);
						glDrawPixels(IceProjL.wid, IceProjL.hei, GL_RGBA, GL_UNSIGNED_BYTE, IceProjL.rgba);
					}
					else
					{
						glRasterPos2i(fb.x, fb.y + IceProjR.hei * 3 / 4);
						glDrawPixels(IceProjR.wid, IceProjR.hei, GL_RGBA, GL_UNSIGNED_BYTE, IceProjR.rgba);
					}
				}
			}
		}
		for (auto& e : exp)
		{
			e.Draw();
		}
		for (auto& bu : bubble)
		{
			if (bu.state_fire == 1)
			{
				glRasterPos2i(bu.x, bu.y + BubProj.hei * 3 / 4);
				glDrawPixels(BubProj.wid, BubProj.hei, GL_RGBA, GL_UNSIGNED_BYTE, BubProj.rgba);
			}
		}
		for (auto& eb : expb)
		{
			eb.Draw();
		}

		glColor3ub(0, 0, 0);
		glRasterPos2i(350, 200);
		if (win == 0)
		{
			YsGlDrawFontBitmap16x20("You lost!");
		}
		else
		{
			YsGlDrawFontBitmap16x20("You won!");
		}

		FsSwapBuffers();

		// Movement commands go here

		for (int i = 0; i < nBall; i++)
		{
			if (0 != flower[i].state)
			{
				flower[i].Move(bg);
			}
		}

		for (auto& fb : fballs)
		{
			if (fb.state_fire == 1)
			{
				fb.move();
			}
			if (fb.x > 800 || fb.x < -10)
			{
				fb.state_fire = 0;
			}
		}

		for (auto& e : exp)
		{
			if (e.state_exp == 1)
			{
				e.Move();
			}
		}

		for (auto& bu : bubble)
		{
			if (bu.state_fire == 1)
			{
				bu.move(diff);
			}
			if (bu.x > 800 || bu.x < -10)
			{
				bu.state_fire = 0;
			}
		}

		for (auto& eb : expb)
		{
			if (eb.state_exp == 1)
			{
				eb.Move();
			}
		}

		if (frog.x == 0 || frog.x == 800 - frog.w)
		{
		frog.prevVx = frog.vx;
		frog.vx = 0;
		frog.prevx = frog.x;
		}

		frog.Move(1);

		FsSleep(10);
	}
}

int main(void)
{
	srand((int)time(NULL));

	FsOpenWindow(0, 0, 800, 600, 1);

    GameMenu menu;
	for (;;)
	{
		menu.Run();
		if (FSKEY_E == menu.key)
		{
			break;
		}

		if (FSKEY_1 == menu.key || FSKEY_2 == menu.key || FSKEY_3 == menu.key)
		{
            menu.chooseDifficulty = 0;
			Game game;
			game.Run(menu.difficulty);
		}

	}

	return 0;
}

