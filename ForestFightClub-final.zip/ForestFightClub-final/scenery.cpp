#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "yspng.h"
#include "fssimplewindow.h"
#include "scenery.h"

void Flower::Initialize(void)
{
	state = 1;
	x = 126 + rand() % 300;
	y = 126 + rand() % 300;

	vx = 1 + rand() % 500;
	vy = 5 + rand() % 5;
}

void Flower::Draw(double cr, int bg)
{
	if (bg == 0)
	{
		glColor3ub(255, 255, 255); // for ice 
	}
	else if (bg == 1)
	{
		glColor3ub(211, 251, 210); //for grass
	}
	else
	{
		glColor3ub(255, 0, 0); // for fire
	}
	glEnable(GL_LINE_WIDTH);
	glLineWidth(5.0);
	glBegin(GL_LINE_STRIP);

	for (int i = 0; i < 250; i++)
	{
		double r=0.0;
		if (bg == 0)
		{
			r = 1 * (sin(i) + cos(i));   //for ice 
		}
		else if (bg == 1)
		{
			r = .5 * i;                  //for grass
		}
		else {
			r = 10.0;                  //for fire
		}
		double a = 2 * YsPi * i / 60;
		double dx = r * cos(a);
		double dy = r * sin(a);

		glVertex2f(x + dx, y + dy);
		//glVertex2f(400,10);
	}
	glEnd();
}

void Flower::Move(int bg)
{
	x = x + vx * dt;
	y = y + vy * dt;
	vx = vx;
	vy = vy - g * dt;
	if (bg == 0)
	{
		if (x < 0.0 && vx < 0.0)
		{
			vx = -vx;
		}
		if (x > 800.0 && vx > 0.0)
		{
			vx = -vx;
		}
		if (y < 0.0 && vy < 0.0)
		{
			vy = -vy;
		}
		if (y > 600.0 && vy > 0.0)
		{
			vy = -vy;
		}
	}
	else if (bg == 1) {
		if (x < 100.0 && vx < 0.0)
		{
			vx = -vx;
		}
		if (x > 675.0 && vx > 0.0)
		{
			vx = -vx;
		}
		if (y < 100.0 && vy < 0.0)
		{
			vy = -vy;
		}
		if (y > 500.0 && vy > 0.0)
		{
			vy = -vy;
		}
	}
	else
	{
		if (x < 10.0 && vx < 0.0)
		{
			vx = -vx;
		}
		if (x > 790.0 && vx > 0.0)
		{
			vx = -vx;
		}
		if (y < 10.0 && vy < 0.0)
		{
			vy = -vy;
		}
		if (y > 590.0 && vy > 0.0)
		{
			vy = -vy;
		}
	}
}

void Block::Initialize(void)
{
	state = 1;
	x = 0;
	y = 40;
	w = hitted;
	h = 20;
}

void Block::Draw(int xi)
{
	glBegin(GL_QUADS);
	glColor3ub(255, 0, 0);
	glVertex2i(xi, y);
	glVertex2i(xi + w, y);
	glVertex2i(xi + w, y + h);
	glVertex2i(xi, y + h);
	glEnd();


}

void Block::Disappear(void)
{
	state = 0;
}

void Block::Notmovebar(int xi)
{
	glBegin(GL_QUADS);
	glColor3ub(40, 240, 120);
	glVertex2i(xi, y);
	glVertex2i(xi + w, y);
	glVertex2i(xi + w, y + h);
	glVertex2i(xi, y + h);
	glEnd();
}