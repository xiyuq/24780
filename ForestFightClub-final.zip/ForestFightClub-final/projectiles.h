#ifndef PROJECTILES_IS_INCLUDED
#define PROJECTILES_IS_INCLUDED
#include "fighters.h"

/*** Fireballs Class ***/
class Fireballs
{
public:
	int x, y, vx, hit, state_fire = 0;
	void fire(Fighters fox);
	void initialize();
	void draw();
	void move();
	int checkhit(Fighters frog);
	class Explosion
	{
	public:

		class Point
		{
		public:
			double x, y;
		};

		class Particle
		{
		public:
			Point p, v;
		};

		enum
		{
			nParticale = 30
		};
		int state_exp;
		int counter;
		Particle particle[30];
		void initialize();
		bool Explode(int x, int y);
		void Draw(void);
		void Move(void);
	};
};

/*** Bubbles Class***/
class Bubbles
{
public:
	int x, y, vx, hit, state_fire = 1;
	void fire(Fighters frog);
	void initialize();
	void draw();
	void move(int diff);
	int checkhit(Fighters fox);
	int checkfb(Fireballs fb);
	class Explosion
	{
	public:

		class Point
		{
		public:
			double x, y;
		};

		class Particle
		{
		public:
			Point p, v;
		};

		enum
		{
			nParticale = 30
		};
		int state_exp;
		int counter;
		Particle particle[30];
		void initialize();
		bool Explode(int x, int y);
		void Draw(void);
		void Move(void);
	};
};

#endif